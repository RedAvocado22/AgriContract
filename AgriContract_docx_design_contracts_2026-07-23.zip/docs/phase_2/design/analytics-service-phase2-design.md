---
name: analytics-service-phase2-design
description: "Analytics-service — CQRS read model thuần tuý, time-series aggregation phục vụ báo cáo quản trị B2B (VICOFA/VRA). Nguồn: design session 06/07/2026, rà soát + fix 4 bug 06/07/2026."
status: DESIGNED — chưa code.
metadata:
  type: design
  phase: 2
  extends: "services.md § analytics-service (8093 — CQRS analytics, time-series aggregation, pre-computed vs real-time tradeoff)"
  related: "milestone-escrow-phase2-design.md §7 (Event Catalog làm nguồn data ingest, gồm event mới `contract.signed` thêm lúc rà soát file này); signature-phase2-design.md §6 (nơi `contract.signed` được publish); reputation-service-phase2-design.md (cùng pattern eventual consistency)"
---

## 1. Bối cảnh & Scope

**Analytics-service là event-driven projection kiêm derived-signal producer** (đổi cách gọi 18/07/2026 — "pure consumer" cũ hết đúng từ khi `AmlPatternScanJob` publish `analytics.structuring_pattern_detected`; 2 bất biến THẬT của thiết kế: **không nằm trên transaction critical path** và **không gọi đồng bộ (REST/Feign) ngược về core service**). Nó không sở hữu bất kỳ quy trình nghiệp vụ lõi nào. Mọi dữ liệu nó có đều phải đến từ việc "nghe" RabbitMQ events. Lý do thiết kế cứng này: analytics là non-critical path. Dù `analytics-service` có sập hay bị quá tải vì query báo cáo nặng, nó tuyệt đối không được tạo tải ngược (cascading failure) lên `contract-service` hay `bank-service` đang xử lý giao dịch.

**Mục tiêu (B2B Agritech context):** Cung cấp các chỉ số đo lường sức khoẻ nền tảng có ý nghĩa thật cho Hiệp hội (VICOFA/VRA) và Admin nền tảng, để ra quyết định vĩ mô. Không vẽ dashboard vô thưởng vô phạt. Cụ thể:
- **Tỷ lệ bẻ kèo (Cancellation/Default Rate):** Đo lường lòng tin vào hợp đồng forward.
- **Hiệu quả Milestone Escrow (Escrow Effectiveness):** Giải quyết câu hỏi "Mô hình chia nhỏ batch có thực sự giúp giảm tỷ lệ vốn bị giam (locked) vô ích so với thực nhận (actual) không?".
- **Xu hướng Bất khả kháng (Force Majeure Trends):** Đo lường rủi ro đứt gãy chuỗi cung ứng do thiên tai theo mùa vụ/ngành hàng.

**Ràng buộc đồ án (5 tháng/5 người):** Giữ stack ở mức MySQL (lưu trữ read model) + Redis (cache API response) + RabbitMQ (ingest) + Spring `@Scheduled` (batch pre-compute). **Đã loại hẳn** ClickHouse, Elasticsearch, Kafka hay Spark — over-engineer so với lượng data của một nền tảng B2B forward contract (vốn có tần suất giao dịch thấp nhưng giá trị cao).

---

## 2. Domain Model — CQRS Read Models

Thiết kế DB tuân theo mô hình **Star Schema thu nhỏ**, tách biệt bảng Dimension (thông tĩnh) và Fact/Aggregate (số liệu).

### 2.1 Bảng Dimension (Tái tạo local state)

Bởi vì không được gọi Feign ngược, analytics phải tự build một bản sao thu gọn của thông tin hợp đồng để dùng làm các "chiều" (dimensions) phân tích (như `commodity`, `buyerId`, `sellerId`).

```sql
CREATE TABLE dim_contract (
    contract_id    CHAR(36) PRIMARY KEY,
    commodity      VARCHAR(50) NOT NULL,
    buyer_id       CHAR(36) NOT NULL,
    seller_id      CHAR(36) NOT NULL,
    total_amount   DECIMAL(15,2) NOT NULL,
    signed_at      TIMESTAMP NOT NULL
);```

**Đã giải quyết (06/07/2026, rà soát lại):** điểm treo trước đây về nguồn `commodity` được chốt bằng cách thêm event mới `contract.signed` vào Event Catalog cấp Contract (`milestone-escrow-phase2-design.md` §7.2), publish đúng 1 lần lúc `Contract.transitionTo(SIGNED)`, payload `{contractId, commodity, buyerId, sellerId, totalAmount, signedAt}`. `dim_contract` được `INSERT` (upsert theo `contract_id`) ngay khi nhận event này — chi tiết ingest ở §3.1 bên dưới. **Cập nhật (08/07/2026):** `commodity` trong payload là enum cứng `COFFEE/RICE/RUBBER/CASHEW`, luôn non-null (analytics chỉ nhận và lưu, không tự map). Cơ chế `commodity` đến từ đâu (`Category.commodity`, admin gán lúc `approve()`, bỏ bảng mapping) chốt ở `product-phase2-design.md` §9 (owner) — không mô tả lại ở đây. Điểm treo mapping trước đây **đã đóng hoàn toàn**.

### 2.2 Sự đánh đổi: Real-time vs Pre-computed

**Vấn đề cốt lõi:** Nếu mọi API dashboard đều gộp data bằng lệnh `SELECT SUM(...) GROUP BY DATE(...)` từ hàng trăm nghìn event thô, DB sẽ nghẽn lúc hiệp hội vào xem báo cáo cuối tháng. Nếu tính sẵn mọi thứ, thì code ingest cực kỳ phức tạp vì phải lo race condition khi nhiều event update cùng 1 bucket.

**Chốt (06/07/2026) — Hybrid Approach (Kết hợp 2 chiến lược):**

1. **Fact Tables (Lưu Raw Events - Ghi cực nhanh, không khoá bảng):**
   Dùng để lưu sự thật gốc rễ, incremental append-only.

   ```sql
   -- Bảng Fact cho Milestone
   CREATE TABLE fact_milestone_performance (
       fact_id                 CHAR(36) PRIMARY KEY,
       contract_id             CHAR(36) NOT NULL,
       milestone_id            CHAR(36) NOT NULL,
       status                  VARCHAR(20) NOT NULL, -- SETTLED / CANCELLED_WITH_PENALTY
       locked_amount           DECIMAL(15,2) NOT NULL,
       actual_amount           DECIMAL(15,2) NOT NULL,
       delta_shortfall_amount  DECIMAL(15,2) NOT NULL, -- = locked - actual
       has_force_majeure       BOOLEAN NOT NULL DEFAULT FALSE,
       resolved_at             TIMESTAMP NOT NULL
   );
   CREATE INDEX idx_fact_milestone_time ON fact_milestone_performance(resolved_at);

   -- Bảng Fact cho Contract Termination (SỬA 19/07/2026 — thay fact_contract_cancellation:
   -- đo "người bấm nút" (initiated_by) là đo NHẦM "người default" — người yêu cầu chấm dứt
   -- không đồng nghĩa người vi phạm (milestone-escrow §6.0). Tách 3 khái niệm để metric
   -- default-rate/cancellation-rate không vu oan bên yếu):
   CREATE TABLE fact_contract_termination (
       fact_id                 CHAR(36) PRIMARY KEY,
       contract_id             CHAR(36) NOT NULL,
       termination_type        VARCHAR(35) NOT NULL, -- MUTUAL_TERMINATION | MUTUAL_REPLACEMENT |
                                                      -- TERMINATION_FOR_BREACH | TERMINATION_FOR_FORCE_MAJEURE |
                                                      -- ACTIVATION_FAILURE
       requested_by            VARCHAR(10) NOT NULL, -- BUYER / SELLER / SYSTEM — ai bấm nút
       final_breaching_role    VARCHAR(10) NULL,     -- BUYER / SELLER / NULL — ai LỖI theo attribution
       breach_reason_code      VARCHAR(30) NULL,     -- taxonomy milestone-escrow §6.4.1
       terminated_at           TIMESTAMP NOT NULL
   );
   CREATE INDEX idx_fact_termination_time ON fact_contract_termination(terminated_at);

   -- Bảng Fact cho Contract Settlement (mới, 06/07/2026 — bug fix)
   -- Lý do bắt buộc phải có bảng riêng: fact_milestone_performance là granularity
   -- MILESTONE, không phải CONTRACT. Một hợp đồng có N milestone, đếm distinct
   -- contract_id từ bảng đó ra "hợp đồng đã hoàn tất" sẽ sai bất cứ khi nào có hợp
   -- đồng đang dở dang (milestone 1,2 đã SETTLED nhưng 3,4,5 còn ACTIVE). Cần nguồn
   -- sự thật riêng ở đúng cấp Contract, lấy thẳng từ event `contract.settled`
   -- (chỉ bắn đúng 1 lần khi TOÀN BỘ milestone đã SETTLED — milestone-escrow §2.2/§7.2).
   CREATE TABLE fact_contract_settlement (
       fact_id                 CHAR(36) PRIMARY KEY,
       contract_id             CHAR(36) NOT NULL,
       settled_at              TIMESTAMP NOT NULL
   );
   CREATE INDEX idx_fact_contract_settlement_time ON fact_contract_settlement(settled_at);
   ```

2. **Pre-computed Aggregate Tables (Tính toán sẵn - Đọc cực nhanh):**
   Dùng cho các metrics phức tạp (tỷ lệ %, chia trung bình). Không cập nhật real-time. Do một job Spring `@Scheduled` chạy batch hàng đêm (VD: 1:00 AM) quét từ bảng Fact để điền vào. Time bucket chia theo **Tháng** (phù hợp với chu kỳ báo cáo nông sản).

   ```sql
   CREATE TABLE agg_monthly_commodity_stats (
       month_id                VARCHAR(7) NOT NULL,  -- Format 'YYYY-MM'
       commodity               VARCHAR(50) NOT NULL,
       total_contracts_settled INT NOT NULL DEFAULT 0,
       -- SỬA 19/07/2026: tách "cancelled" gộp thành 4 cột — mutual không phải default,
       -- gộp chung làm cancellation_rate cao giả tạo và không nói được AI vi phạm:
       total_mutual_exits      INT NOT NULL DEFAULT 0,  -- MUTUAL_TERMINATION + MUTUAL_REPLACEMENT
       total_seller_breaches   INT NOT NULL DEFAULT 0,  -- final_breaching_role = SELLER
       total_buyer_breaches    INT NOT NULL DEFAULT 0,  -- final_breaching_role = BUYER
       total_no_fault_exits    INT NOT NULL DEFAULT 0,  -- FM + ACTIVATION_FAILURE
       seller_breach_rate      DECIMAL(5,4) NOT NULL DEFAULT 0,
       buyer_breach_rate       DECIMAL(5,4) NOT NULL DEFAULT 0,
       force_majeure_incidents INT NOT NULL DEFAULT 0,
       total_value_settled     DECIMAL(15,2) NOT NULL DEFAULT 0,
       escrow_efficiency_rate  DECIMAL(5,4) NOT NULL DEFAULT 0, -- (actual_amount / locked_amount) toàn tháng
       PRIMARY KEY (month_id, commodity)
   );
   ```

### 2.3 Idempotency Log (Ràng buộc bắt buộc cho Analytics)

RabbitMQ đảm bảo at-least-once delivery. Nếu 1 event `milestone.settled` bị kẹt và gửi lại 2 lần, số tiền trong hệ thống báo cáo sẽ bị nhân đôi. Analytics nhạy cảm với vụ này không kém gì bank-service.

```sql
CREATE TABLE analytics_idempotency_log (
    message_id      VARCHAR(255) PRIMARY KEY, -- ID của RabbitMQ message
    processed_at    TIMESTAMP NOT NULL DEFAULT now()
);```

### 2.4 Bảng staging cho `has_force_majeure` (mới, 06/07/2026 — bug fix race condition)

**Vấn đề:** `milestone.force_majeure_resolved` (dispute) luôn xảy ra **trước** khi milestone đạt trạng thái cuối (`SETTLED`/`CANCELLED_WITH_PENALTY`) — nhưng `fact_milestone_performance` chỉ được `INSERT` khi nhận đúng 2 event cuối đó (§3.2). Nếu ingest pipeline chỉ biết `UPDATE ... SET has_force_majeure = TRUE WHERE milestone_id = X`, row đó chưa tồn tại lúc `resolved` tới → `UPDATE` chạy vào khoảng không, 0 row bị ảnh hưởng, cờ vĩnh viễn `FALSE`.

**Giải pháp — staging table, merge lúc INSERT:**

```sql
CREATE TABLE pending_force_majeure_flag (
    milestone_id    CHAR(36) PRIMARY KEY,
    flagged_at      TIMESTAMP NOT NULL
);```

Cơ chế 2 chiều (an toàn bất kể thứ tự event tới, dù thứ tự thực tế luôn là resolved-trước):
1. Nhận `force_majeure_resolved` (APPROVED) → thử `UPDATE fact_milestone_performance SET has_force_majeure = TRUE WHERE milestone_id = X`. Nếu `rows affected = 0` (row chưa tồn tại — trường hợp thường gặp) → `INSERT` vào `pending_force_majeure_flag`.
2. Lúc `INSERT` vào `fact_milestone_performance` (từ `settled`/`cancelled_with_penalty`, §3.2) → `SELECT` trước từ `pending_force_majeure_flag` theo `milestone_id`; nếu có → set `has_force_majeure = TRUE` ngay trong câu `INSERT`, rồi `DELETE` row staging đó.

---

## 3. Ingest Pipeline

Mỗi khi nhận event từ RabbitMQ, pipeline xử lý phải đi qua bước check `analytics_idempotency_log`. Nếu đã xử lý → skip ngay lập tức.

### 3.1 Nhóm Event "Contract Signed" — populate Dimension (mới, 06/07/2026)
*(Nguồn: milestone-escrow-phase2-design.md §7.2 — event mới, thêm cùng lúc review này)*

* **Nhận `contract.signed` (mang `commodity`, `buyerId`, `sellerId`, `totalAmount`, `signedAt`):**
    * *Hành động:* `UPSERT` vào `dim_contract` theo `contract_id`. Phải xử lý event này **trước** các event milestone/settlement của cùng `contractId` về mặt logic (không bắt buộc về thứ tự nhận trên RabbitMQ, nhưng batch job §3.4 JOIN `dim_contract` nên nếu dimension chưa kịp có, dòng đó tạm thời thiếu `commodity` ở lần chạy batch gần nhất — tự vá lại ở lần chạy kế tiếp, không mất dữ liệu, chỉ trễ 1 chu kỳ).

### 3.2 Nhóm Event "Milestone Escrow"
*(Nguồn: milestone-escrow-phase2-design.md §7.1)*

* **Nhận `milestone.settled` (mang `lockedAmount`, `actualAmount`):**
    * *Hành động:* Trước khi `INSERT`, `SELECT` từ `pending_force_majeure_flag` (§2.4) theo `milestone_id`. `INSERT` vào `fact_milestone_performance`, tính `delta_shortfall_amount = lockedAmount - actualAmount`, set `has_force_majeure = TRUE` nếu tìm thấy row staging tương ứng, rồi `DELETE` row staging đó.
    * *Chiến lược:* Ghi incremental, không group ngay. Nhanh và triệt tiêu table lock contention.
* **Nhận `milestone.force_majeure_resolved` (chỉ ghi nhận khi APPROVED):**
    * *Hành động (sửa 06/07/2026 — bug race condition):* Event này luôn tới **trước** khi milestone đạt trạng thái cuối, nên `fact_milestone_performance` gần như chắc chắn **chưa có row** để `UPDATE`. Thử `UPDATE fact_milestone_performance SET has_force_majeure = TRUE WHERE milestone_id = X` trước; nếu `rows affected = 0` → `INSERT` vào `pending_force_majeure_flag` (§2.4) để chờ merge lúc `INSERT` fact row thật (2 bước trên/dưới mục này).
* **Nhận `milestone.cancelled_with_penalty` (lưu ý 19/07/2026 — event này giờ CHỈ bắn sau attribution, milestone-escrow §7.1/§6.4; tần suất sẽ thấp hơn thiết kế cũ vì Delta 1 không còn tự bắn):**
    * *Hành động:* Cùng logic merge staging như `milestone.settled` ở trên. `INSERT` vào `fact_milestone_performance` với `status = CANCELLED`, `actual_amount = 0`, kiểm tra + merge `pending_force_majeure_flag` trước khi insert.

### 3.3 Nhóm Event "Contract Level — Settlement/Termination" (đổi tên 19/07/2026)
*(Nguồn: milestone-escrow-phase2-design.md §7.2)*

* **Nhận `contract.settled` (mới, 06/07/2026 — bug fix, trước đây không consume event này):**
    * *Hành động:* `INSERT` vào `fact_contract_settlement`. Đây là nguồn **duy nhất** đúng để đếm "hợp đồng đã hoàn tất" ở granularity Contract — không được suy ra từ `fact_milestone_performance` (đó là granularity Milestone, xem lý do tại §2.2).
* **Nhận `contract.terminated` (SỬA 19/07/2026 — thay `contract.cancelled`; payload mang `terminationType`/`requestedBy`/`finalBreachingRole`/`breachReasonCode?`):**
    * *Hành động:* `INSERT` vào `fact_contract_termination` với đủ 3 khái niệm tách bạch. **Không map `requestedBy` vào cột "người vi phạm"** — đó chính là bug đo nhầm đã sửa.
* *(Sửa 19/07 lần 2 — BỎ consumer `remedy.finalized`: `contract.terminated` giờ mang thẳng `breachReasonCode`/`remedyDecisionId` trong payload nên analytics đọc một event là đủ; bớt một consumer, bớt một đường eventual-consistency phải test.)*

### 3.4 Batch Job `@Scheduled` (Pre-compute)

**Chốt (06/07/2026):** Job `MonthlyAggregationJob` chạy lúc **1:00 AM mỗi ngày** (off-peak, trước giờ `VerifyChainJob` của audit-service 2:00 AM để tránh dẫm chân tài nguyên DB nội bộ nếu triển khai chung node).
* *Cách chạy (**sửa 19/07 lần 3; hiệu chỉnh theo granularity bucket cùng ngày**):* bucket của `agg_monthly_commodity_stats` là **THÁNG** (`PRIMARY KEY (month_id, commodity)`) — không có bucket ngày để "recompute D-7..D-1". Job mỗi ngày: xác định cửa sổ trễ 7 ngày `[D-7, D-1]`, rồi **recompute NGUYÊN từng bucket tháng bị cửa sổ đó chạm** (thường là tháng hiện tại; những ngày đầu tháng thì thêm cả tháng trước) — quét **toàn bộ facts của tháng đó** (không chỉ facts trong cửa sổ) từ `fact_contract_settlement` + `fact_contract_termination` (JOIN `dim_contract` lấy `commodity`) và `fact_milestone_performance`, tính lại đủ mọi cột, rồi **SET ghi đè bucket, KHÔNG `+=`**. Lý do bỏ cách cũ: (a) event tới muộn sau khi job đã chạy → job quét-hôm-qua không bao giờ quay lại — "lần chạy kế tiếp tự vá" là lời hứa sai; (b) rerun kiểu increment-upsert → cộng hai lần. Recompute-cả-tháng + SET là idempotent tự nhiên: rerun bao nhiêu lần cũng ra cùng số, event trễ ≤7 ngày tự được vá ở lần chạy kế. Chi phí quét cả tháng chấp nhận được — nền B2B forward tần suất giao dịch thấp (§1). Event trễ >7 ngày: chấp nhận sai số (read model, không phải evidence ledger); cần thì trigger recompute tay theo `month_id`. Phân loại termination vào 4 cột theo `termination_type` + `final_breaching_role` (§2.2).
* *Tính Rate (SỬA 19/07/2026 — tách rate theo attribution, không còn 1 cancellation_rate gộp):* `seller_breach_rate = total_seller_breaches / (total_contracts_settled + total_seller_breaches + total_buyer_breaches)`; `buyer_breach_rate` mirror. **Mutual exits và no-fault KHÔNG vào mẫu số breach rate như "vi phạm"** — gộp chung sẽ thổi phồng "tỷ lệ bẻ kèo" bằng cả những cặp chia tay thiện chí, đo sai đúng cái metric mà hiệp hội dựa vào để đánh giá lòng tin thị trường.

### 3.5 Batch Job AML — `AmlPatternScanJob` (mới, 10/07/2026 — đóng gap structuring chậm §9 reputation-service)

**Bối cảnh — vì sao phải là batch, không dồn vào tầng realtime:** `reputation-service` §8 đã có 2 tầng phát hiện chạy realtime — nhóm tín hiệu tương đối (cửa sổ ngắn, bắt structuring dồn trong vài ngày) + nhóm tuyệt đối (ngưỡng 500 triệu, bắt one-shot lớn). Cả 2 đều **không thể** bắt kịch bản rải mỏng: kẻ gian đẩy đều đặn nhiều hợp đồng ~490 triệu (dưới ngưỡng tuyệt đối) giãn cách nhiều tuần/tháng (ngoài cửa sổ tương đối). Mỗi hợp đồng đứng riêng đều vô hại — chỉ khi nhìn xuyên nhiều tháng mới thấy *hình dạng* structuring. Đây đúng là việc của batch phân tích hành vi cộng dồn trên data warehouse (`reputation-service` §9 đã ghi nhận đây là gap còn hở, không đóng được bằng công cụ pattern realtime).

**Chốt (10/07/2026):** job `AmlPatternScanJob` chạy `@Scheduled` **riêng biệt**, KHÔNG gộp vào `MonthlyAggregationJob` — 2 job khác mục đích hoàn toàn (`MonthlyAggregationJob` = báo cáo thương mại vĩ mô cho dashboard hiệp hội; `AmlPatternScanJob` = phát hiện gian lận). Trộn chung làm 1 job vi phạm single-responsibility, và lịch chạy/tần suất/xử lý lỗi khác nhau.

**Nguồn dữ liệu — JOIN, không thêm cột:** `dim_contract` đã có sẵn `buyer_id`, `seller_id`, `total_amount`; `fact_contract_settlement` có `contract_id` + `settled_at`. Job JOIN 2 bảng theo `contract_id`, KHÔNG cần thêm `total_amount` vào bảng fact (tránh phải sửa payload event `contract.settled` — cascade không cần thiết).

```sql
-- Quét cụm near-threshold theo cặp buyer-seller, cửa sổ 90 ngày.
SELECT dc.buyer_id, dc.seller_id,
       COUNT(*) AS near_threshold_count,
       JSON_ARRAYAGG(fcs.contract_id) AS contract_ids  -- MySQL 8 (sửa dialect 18/07/2026, ARRAY_AGG là Postgres)
FROM   fact_contract_settlement fcs
JOIN   dim_contract dc ON dc.contract_id = fcs.contract_id
WHERE  fcs.settled_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)  -- MySQL 8 (sửa dialect 18/07/2026)
  AND  dc.total_amount >= 475000000      -- [95%, 100%) của ngưỡng 500 triệu
  AND  dc.total_amount <  500000000
GROUP BY dc.buyer_id, dc.seller_id
HAVING COUNT(*) >= 5;                     -- min 5 hợp đồng near-threshold cùng cặp```

**3 tham số (số cứng, không placeholder — dẫn từ ngưỡng luật định 500 triệu, đã public):**
- **Band near-threshold: `[475 triệu, 500 triệu)`** = `[95%, 100%)` của ngưỡng. Bám sát mép báo cáo. *Band một mình KHÔNG phải tín hiệu* — tín hiệu thật là **clustering low-variance**: nhiều hợp đồng dồn trong dải hẹp sát mép. Cặp làm ăn thật deal to-nhỏ lẫn lộn (ví dụ Doc02: 13,5-135 tỷ), không cluster quanh đúng 490 triệu.
- **Min count: 5 hợp đồng** near-threshold cùng cặp trong window. Dưới 5 là bằng chứng yếu → false-positive cặp mua lặp hợp pháp.
- **Lookback: 90 ngày.** Phải dài hơn hẳn cửa sổ realtime (48-72h) vì bắt slow-drip. Neo ~1 chu kỳ vụ; dài hơn thì vắt qua nhiều mùa không liên quan (nhiễu), ngắn hơn thì lọt kẻ rải mỏng.

**Output — publish event, KHÔNG tự quyết định gì:** bắt cụm → `analytics-service` publish `analytics.structuring_pattern_detected`. `analytics-service` là **event-driven projection kiêm derived-signal producer** (sửa cách gọi 18/07/2026 — "pure consumer" cũ không còn chính xác vì job này publish event; điểm bất biến thật là: không nằm trên transaction critical path, không gọi sync ngược core service), **không** tự hold giao dịch, **không** tự flag reputation, **không** tự báo cáo cơ quan — chỉ phát hiện và phát tín hiệu. Ai xử lý là việc của consumer.

| Event | Payload | Consumers |
|---|---|---|
| `analytics.structuring_pattern_detected` | `{buyerId, sellerId, contractIds[], nearThresholdCount, windowStart, windowEnd, detectedAt}` | **`reputation-service`** (set cặp `ELEVATED_RISK` — `reputation-service-phase2-design.md` §8) · **`bank-service`** (báo cáo giao dịch khả nghi cho cơ quan — nghĩa vụ Luật PCRT 2022, đúng chủ thể pháp lý giữ tiền; consumer đã có trong `bank-service-phase2-design.md` §3.4b (cập nhật 18/07/2026 — bỏ trạng thái "cần thêm")) |

**Giới hạn cấu trúc (ghi rõ, không cố lấp):** batch chỉ thấy hình sau khi các mảnh **đã settle** — vài hợp đồng đầu (trước khi đủ cụm ≥5) chắc chắn lọt, tiền đã đi. Không thiết kế nào bắt được mảnh đầu của một pattern chưa thành hình. Batch **không** cứu one-shot nhỏ lẻ (1 hợp đồng dưới ngưỡng rồi biến — không đủ cụm). Nó chỉ đóng đúng phần slow-drip *có lặp lại* — xem `reputation-service-phase2-design.md` §9 để biết residual còn lại.

---

## 4. API Endpoints

Các API này phục vụ Dashboard của Admin/Hiệp hội, nên được Redis cache với TTL 1 giờ (dữ liệu phân tích vĩ mô không cần fresh tới từng giây).

### 4.1. Báo cáo Termination theo Ngành hàng (SỬA 19/07/2026 — thay "Tỷ lệ bẻ kèo" gộp)
Đo lường lòng tin vào hợp đồng forward — nhưng đo đúng: breach rate tách theo bên vi phạm (attribution), mutual/no-fault báo riêng, không gộp thành một "tỷ lệ bẻ kèo" vu cả những cặp chia tay thiện chí.

* `GET /api/v1/analytics/terminations?year={YYYY}`
* **Response Shape:**
    ```json
    {
      "year": "2026",
      "data": [
        {
          "commodity": "COFFEE",
          "totalSettled": 120,
          "sellerBreaches": 9,
          "buyerBreaches": 4,
          "mutualExits": 6,
          "noFaultExits": 2,
          "sellerBreachRate": 0.0677,
          "buyerBreachRate": 0.0301
        }
      ]
    }
    ```

### 4.2. Hiệu quả Milestone Escrow (Escrow Effectiveness)
Chứng minh giá trị thật của cơ chế Milestone Phase 2 so với Two-phase lock Phase 1. Trả lời câu hỏi: "Tiền bị khoá (locked_amount) có thực sự bám sát thực nhận (actual_amount) không, hay đang khoá dư thừa?".

* `GET /api/v1/analytics/escrow-effectiveness?month={YYYY-MM}`
* **Response Shape:**
    ```json
    {
      "month": "2026-10",
      "metrics": {
        "totalLockedVolume": 5000000000,
        "totalActualDisbursed": 4850000000,
        "totalShortfallDelta": 150000000,
        "escrowEfficiencyRate": 0.97,
        "forceMajeureImpact": 50000000
      }
    }
    ```

### 4.3. Xu hướng Bất khả kháng (Force Majeure Trends)
Rất quan trọng với VICOFA/VRA để báo cáo tình hình chuỗi cung ứng với Bộ NN&PTNT.

* `GET /api/v1/analytics/force-majeure-trends?year={YYYY}`
* **Response Shape:**
    ```json
    {
      "year": "2026",
      "totalIncidents": 24,
      "byCommodity": {
        "COFFEE": 18,
        "RICE": 6
      },
      "peakMonths": ["2026-09", "2026-10"] // Các tháng có bão lũ
    }
    ```

---

## 5. Known Limitations (Giới hạn có chủ đích)

Những điều này phải báo cáo thẳng thắn với hội đồng bảo vệ, đây là sự đánh đổi kinh điển của kiến trúc Event-Driven/CQRS, không phải bug:

1.  **Eventual Consistency & Data Lag (Độ trễ dữ liệu):** Dữ liệu trên Dashboard sẽ không khớp tới từng VNĐ ngay thời điểm hiện tại so với `bank-service` hay `contract-service`. Có hai lớp lag:
    * *Lag hệ thống:* Độ trễ của RabbitMQ (thường là mili-giây, nhưng có thể lâu hơn nếu queue kẹt).
    * *Lag nghiệp vụ:* Bảng `agg_monthly_commodity_stats` chỉ được cập nhật qua batch job 1:00 AM. Những thay đổi trong ngày hôm nay sẽ không phản ánh vào các biểu đồ chia rate (%) cho tới ngày mai.
2.  **Không có Historical Backfill (Dữ liệu quá khứ trống không):** Vì service này không có API gọi ngược (event-driven projection), nếu deploy `analytics-service` vào giữa Phase 2 (tháng thứ 3 chẳng hạn), nó sẽ chỉ bắt đầu ghi nhận data từ ngày deploy. Các hợp đồng đã SETTLED ở tháng 1, tháng 2 sẽ không tồn tại trên dashboard trừ khi ta viết script thủ công tái phát (replay) event từ `audit-service` đẩy vào lại RabbitMQ. Đây là cái giá thật của event-driven architecture.
3.  **Không bắt được thay đổi cấu trúc bảng cũ:** Nếu `milestone-escrow` quyết định sửa lịch sử giao dịch (data fix tay bằng SQL từ phía Admin), event RabbitMQ không được sinh ra, dẫn đến `analytics-service` sẽ vĩnh viễn bị lệch số so với DB gốc.

---

## 6. Status — Analytics-service Design

**Chốt (06/07/2026, cách gọi sửa 18/07/2026):** `analytics-service` là event-driven projection/CQRS read-model kiêm derived-signal producer (không critical path, không sync ngược core), không phụ thuộc đồng bộ vào service nào. Áp dụng mô hình Star Schema thu nhỏ: `fact` tables (lưu event thô incremental, giải quyết nghẽn ghi) + `agg` tables (pre-computed định kỳ 1:00 AM bằng `@Scheduled`, giải quyết nghẽn đọc/tính toán %). Bắt buộc có bảng Log Idempotency theo `message_id` để tránh at-least-once làm lặp số. Metric tập trung hoàn toàn vào B2B value (termination theo attribution — sửa 19/07/2026, force majeure, escrow effectiveness). Chấp nhận độ trễ (data lag) và trống data quá khứ lúc mới deploy làm tradeoff.

**Sửa (06/07/2026, rà soát lại sau khi đóng session lần đầu) — 4 vấn đề phát hiện, cả 4 đã fix trong bản này:**
1. `total_contracts_settled` không thể tính đúng từ `fact_milestone_performance` (sai granularity: Milestone ≠ Contract) → thêm `fact_contract_settlement`, populate từ event `contract.settled` (§2.2, §3.3).
2. `analytics-service` chưa được đăng ký làm consumer của `contract.settled`/`contract.terminated` (tên cũ `contract.cancelled`) trong Event Catalog gốc (`milestone-escrow-phase2-design.md` §7.2) dù tự ý consume — đã thêm vào bảng consumer ở file đó.
3. `dim_contract` chưa từng được wire vào ingest pipeline nào — thêm event mới `contract.signed` (`milestone-escrow-phase2-design.md` §7.2) + bước ingest §3.1.
4. `has_force_majeure` gần như luôn `FALSE` do race condition (event `resolved` luôn tới trước khi fact row tồn tại) → thêm bảng staging `pending_force_majeure_flag` (§2.4), merge 2 chiều lúc `INSERT`.

**Nguồn `commodity` đã đóng hoàn toàn (08/07/2026):** `commodity` non-null, đọc từ `Category.commodity`. Cơ chế chốt ở `product-phase2-design.md` §9 (owner).

**Chốt bổ sung (10/07/2026) — `AmlPatternScanJob` đóng gap structuring chậm (§3.5):** thêm job batch AML riêng (KHÔNG gộp `MonthlyAggregationJob`) quét cụm near-threshold `[475tr, 500tr)`, min 5 hợp đồng/cặp, lookback 90 ngày, JOIN `dim_contract` (đã có `total_amount`/`buyer_id`/`seller_id`) — **không** thêm cột vào `fact_contract_settlement`, tránh sửa payload `contract.settled`. Bắt cụm → publish `analytics.structuring_pattern_detected`; `analytics-service` chỉ phát hiện, không tự hold/flag/báo cáo (derived-signal producer — không critical path, không sync ngược). Consumer: `reputation-service` (ELEVATED_RISK) + `bank-service` (báo cáo cơ quan). Đóng đúng phần slow-drip có lặp mà 2 tầng realtime của `reputation-service` (§8) không bắt được; residual (vài mảnh đầu + one-shot nhỏ lẻ) ghi rõ ở `reputation-service-phase2-design.md` §9.

Analytics-service — **ĐÓNG SESSION HOÀN TOÀN, service cuối cùng của Phase 2, sẵn sàng đưa vào Architecture/SDS/TechnicalSpec chính thức.** Điểm treo mapping `commodity` đã đóng hoàn toàn (08/07/2026, §2.3) — `commodity` non-null đọc từ `Category.commodity`, cơ chế chốt ở `product-phase2-design.md` §9. Không còn điểm treo.

---

*Design session: 06/07/2026 · Rà soát + fix 4 bug: 06/07/2026 · Cập nhật 13/07/2026 (gỡ câu điều kiện thừa ở Status) · Cập nhật 19/07/2026 (đợt 6 — fact_contract_termination thay fact_contract_cancellation: tách terminationType/requestedBy/finalBreachingRole; agg tách seller/buyer breach rate khỏi mutual/no-fault; API /terminations thay /cancellations; consume contract.terminated — review lần 2: payload đủ field, bỏ consumer remedy.finalized; lần 3: MonthlyAggregationJob đổi sang rolling recompute + SET-ghi-đè, hiệu chỉnh cùng ngày theo granularity: recompute nguyên bucket THÁNG bị cửa sổ D-7..D-1 chạm — schema là monthly, không có bucket ngày) · Chưa code · **Đã đóng kiến trúc Phase 2 tổng thể — sẵn sàng đưa vào Architecture/SDS/TechnicalSpec chính thức.***
