---
name: bank-service-phase2-design
description: "Bank-service — mock legal custody cho tiền, mô hình FBO/ledger thay vì account-per-contract. Nguồn: design session 03/07/2026, cập nhật 04/07/2026, 08/07/2026 (tách entryType 2 loại cọc, mapping Provisional Settlement Level 2, bank.large_transaction_flagged), 19/07/2026 (tách SEIZE_PENALTY → DEPOSIT_FORFEITURE/CONTRACTUAL_PENALTY/DAMAGES_COMPENSATION; mọi hậu quả tiền termination đi duy nhất qua remedy.finalized/remedyLegs, contract.terminated không kích ledger)."
status: DESIGNED — chưa code.
metadata:
  type: design
  phase: 2
  extends: "services.md § bank-service (8086)"
  related: "milestone-escrow-phase2-design.md §2.1, §2.1b (LegalProfile), §2.3, §6, §6.4 (BreachCase), §6.7, §6b, §7 (nguồn amount cần lock/release/seize + 2 event cấp Contract mới); AgriContract_02_GiaiPhap_MoHinh_v5.docx Tầng 5 (Escrow Holder — Ngân hàng), §3.3 (superseded, xem Known Limitations)"
---

## 1. Bối cảnh & Scope

**Chốt (03/07/2026):** bank-service Phase 2 chỉ giữ **đúng 1 chức năng** — legal custody hợp pháp cho tiền, giải quyết "Rủi ro 1 — nghiêm trọng nhất" trong `AgriContract_02_GiaiPhap_MoHinh_v5.docx` (Nghị định 52/2024, Điều 8, Khoản 7 — cấm cung ứng trung gian thanh toán không phép). Platform (escrow-service) không tự giữ tiền, chỉ ra lệnh; bank-service là nơi tiền (mock) thực sự nằm.

**Không phải arbitrator.** Vai trò "ngân hàng đóng arbitrator độc lập" trong docx gốc (§3.3) bị **superseded** bởi INSPECTOR 3-tier + symmetric escalation đã build (`milestone-escrow-phase2-design.md` §5). Lý do: arbitrator đòi hỏi 3 điều kiện — độc lập, trách nhiệm pháp lý, không skin-in-the-game — chỉ đúng nếu ngân hàng đó **thật**, được NHNN giám sát thật. Bank-service Phase 2 vẫn mock (không ngân hàng nào ký API cho 1 đồ án), nên không thoả được 3 điều kiện đó — dùng mock bank làm arbitrator tạo cảm giác độc lập giả, tệ hơn không có. Đã ghi vào `decisions.md` — `[2026-07-03] Ngân hàng-arbitrator (docx v5 §3.3) — superseded bởi INSPECTOR 3-tier`.

**Không tích hợp thật trong Phase 2.** `AgriContract_02` §4.2 (roadmap) ghi "Bank Integration — Tích hợp escrow thật" như 1 mục tiêu — không đạt được trong giới hạn đồ án. Bank-service thiết kế để **nếu sau này có ai tích hợp thật**, escrow-service không cần sửa business logic — đúng claim docx tự đưa ra ở FAQ ("logic không đổi khi swap mock bằng Agribank API thật"), nhưng claim đó chỉ đúng nếu ranh giới interface sạch ngay từ Phase 2 (xem §3).

---

## 2. Domain Model — Ledger, không phải Account-per-Contract

**Vấn đề với model "mỗi contract 1 account":** không khớp cách ngân hàng/fintech thật vận hành, và tạo race condition lúc provisioning (account phải tồn tại trước khi lock, nhưng trigger tạo account lại đặt sau thời điểm cần lock — gà-trứng).

**Chốt (03/07/2026) — mô hình FBO/Omnibus (chuẩn công nghiệp: PayPal, ví điện tử, escrow bất động sản, marketplace escrow):** chỉ **1 chỗ giữ tiền chung** (mock — không cần model chi tiết, chỉ cần biết tổng luôn khớp với tổng ledger). Toàn bộ chi tiết "ai sở hữu bao nhiêu, cho việc gì" nằm trong **`LedgerEntry`** — append-only, không sửa/xoá sau khi ghi, cùng nguyên tắc `audit_record` đã áp ở hash-chain design.

Số dư (buyer còn bao nhiêu, đang khoá bao nhiêu cho hợp đồng nào) **không lưu sẵn** ở đâu cả — luôn là **kết quả cộng dồn** từ các dòng `LedgerEntry` liên quan, tính lúc cần, không đọc 1 ô có sẵn rồi hy vọng nó đúng.

| Field | Loại | Ghi chú |
|---|---|---|
| `entryId` | UUID | |
| `sourceEventId` | UUID | ID của event gốc kích hoạt entry này (từ Outbox message escrow-service gửi sang) — dùng làm idempotency key, xem §4 |
| `contractId` | UUID | Bắt buộc — tách hợp đồng này với hợp đồng khác |
| `milestoneId` | UUID, nullable | **NULL nếu là cọc cấp Contract** (`buyerDepositRate` hoặc `sellerDepositRate` — khoá 1 lần lúc SIGNED, không thuộc milestone nào — release/seize qua `remedy.finalized` legs), có giá trị nếu là `batchAmount` của 1 milestone cụ thể (`milestone.settled`/remedy legs) — 2 loại khoá này đá vào 2 field khác nhau của `ContractTerms` (`milestone-escrow-phase2-design.md` §2.1), không được gộp chung |
| `userId` | UUID | Buyer hoặc seller, tuỳ `entryType` |
| `entryType` | Enum | `LOCK_BUYER_DEPOSIT` \| `LOCK_SELLER_DEPOSIT` \| `LOCK_MILESTONE` \| `RELEASE_TO_SELLER` \| `REFUND_TO_BUYER` \| `DEPOSIT_FORFEITURE` \| `CONTRACTUAL_PENALTY` \| `DAMAGES_COMPENSATION` (**sửa 08/07/2026** — tách `LOCK_DEPOSIT` cũ thành 2 giá trị; **sửa 19/07/2026** — tách `SEIZE_PENALTY` cũ thành 3 remedyType, xem ghi chú dưới) |
| `fundType` | Enum (**mới 19/07/2026 lần 2**) | `BUYER_DEPOSIT` \| `SELLER_DEPOSIT` \| `MILESTONE_PAYMENT` — `entryType` một mình trộn operation với semantics: `RELEASE_TO_SELLER` vừa có thể là **tiền bán hàng** (fund = MILESTONE_PAYMENT) vừa có thể là **trả lại cọc của chính seller** (fund = SELLER_DEPOSIT). Statement export (§5b.2) và `LedgerAuditReconciliationJob` (§5b.1) cần biết tiền thuộc quỹ nào mà không đoán semantics từ `entryType` + `milestoneId` |
| `remedyDecisionId` | UUID, nullable (**mới 19/07/2026 lần 2**) | Trỏ về `remedy.finalized.remedyDecisionId` sinh ra entry này — `NULL` cho lock/release thường (không phải chế tài). Cho phép reconcile "một quyết định → đúng một bộ legs" (matrix 11o) và statement giải thích được từng khoản seize thuộc phán quyết nào |
| `amount` | Money | |
| `createdAt` | Timestamp | |

`UNIQUE(sourceEventId)` — chặn duplicate xử lý cùng 1 event 2 lần (xem §4).

**Sửa (08/07/2026) — comment schema sai + không phân biệt được 2 loại cọc từ ledger thô:** comment cũ (`bank-service-phase2-design.md` §6 + SDS) ghi *"`milestoneId = NULL` = `buyerDepositRate`"* — sai từ 06/07/2026 khi `sellerDepositRate` optional ra đời, vì seller deposit cũng lock với `milestoneId = NULL`. Có **2 khoản `LOCK` cấp Contract** cùng `milestoneId = NULL`, trước đây phân biệt được qua `userId` (biết ai là buyer/seller của contract) **nhưng** bank-service tự nó agnostic — không biết `userId` nào là buyer/seller nếu chỉ đọc ledger thô, phải tra ngược sang contract-service mới biết. Ngược tinh thần "bằng chứng tự đứng" (ledger tự giải thích được, không cần tra chéo service khác) đã theo suốt thiết kế. **Chốt:** tách `entryType` thành `LOCK_BUYER_DEPOSIT`/`LOCK_SELLER_DEPOSIT` thay vì chung `LOCK_DEPOSIT` — ledger tự giải thích được ngay, không cần biết `userId` là ai. Enum thêm 1 giá trị, rẻ hơn phương án thêm cột `deposit_party` riêng.

**Sửa (19/07/2026) — tách `SEIZE_PENALTY` thành 3 remedyType, cùng lý do "ledger tự giải thích được" đã dùng cho 2 lần tách trước:** `SEIZE_PENALTY` gộp chung là mù về pháp lý — luật Việt Nam có **3 chế tài tiền khác nhau, trần khác nhau** (`milestone-escrow-phase2-design.md` §2.1b), và một entry `SEIZE_PENALTY` không nói được nó là khoản nào → không đặt được cap đúng chỗ, không chặn được **double recovery** (thu trùng một tổn thất qua nhiều khoản). Tách:

- `DEPOSIT_FORFEITURE` — mất cọc (BLDS 2015 Điều 328, **không** cap 8%). Seize `buyerDepositRate`/`sellerDepositRate` khi bên đó là `finalBreachingRole`.
- `CONTRACTUAL_PENALTY` — phạt vi phạm (LTM 2005 Điều 300–301, **cap 8% giá trị phần nghĩa vụ bị vi phạm** — validate ở contract-service lúc `sign()` qua `LegalProfile`, bank chỉ ghi số đã tính). Seize theo `buyerPenaltyRate`/`sellerPenaltyRate` × batchAmount phần bị vi phạm.
- `DAMAGES_COMPENSATION` — bồi thường thiệt hại (LTM Điều 302, không cap nhưng phải chứng minh thiệt hại thật; điều kiện theo `damagesPolicy` của LegalProfile (milestone-escrow §2.1b — với `COMMERCIAL_CUMULATIVE_IF_PROVEN` chỉ cần phán quyết/bằng chứng thiệt hại) — không tự sinh từ tỷ lệ).

`REFUND_TO_BUYER`/`RELEASE_TO_SELLER` sẵn có tiếp tục dùng cho mọi hoàn tiền **không mang tính phạt** (cọc về chủ khi mutual/FM/technical-fail, refund leg activation/funding fail) — không đẻ tên mới cho nghĩa đã có. **Bank vẫn "dumb"**: contract-service (remedy calculator, sau `remedy.finalized`) tính legs + chịu trách nhiệm cap/chống-double-recovery; escrow-service validate conservation; bank chỉ ghi entry theo `entryType` + amount dương nhận được — đúng phân vai §3.3 đã có.

---

## 2b. Bất biến kế toán của ledger (làm rõ 21/07/2026 — đóng gap GPT/appraisal nêu)

Model FBO/Omnibus append-only ở §2 đã ngầm định các quy tắc tiền dưới đây; mục này ghi tường minh để phần code không tự suy diễn khác nhau. Không thêm hành vi mới — chỉ formalize cái §2/§3/§5 đã dựa vào.

1. **Đơn vị tiền — 1 currency, không đa tệ trong scope.** Mọi `amount` là **VND** (ISO 4217 `VND`). Không có field currency per-entry vì hệ chỉ 1 tệ; nếu sau này đa tệ thì thêm `currency` cấp `contract` (immutable per contract) — ghi Known Limitation, không làm bây giờ.

2. **Scale & làm tròn — cố định, tính một nơi.** `amount` lưu `DECIMAL(18,2)` (khớp money pattern `^[0-9]+\.[0-9]{2}$` ở event schema), scale = 2, luôn **HALF_UP**. **Làm tròn chỉ xảy ra ở `contract-service`** khi tính `remedyLegs`/`actualAmount` (nơi có đủ `ContractTerms`); bank nhận số đã tính sẵn và **không tự nhân/chia lại** (§3.1/§3.2) — nên không có 2 nơi làm tròn lệch nhau.

3. **Mô hình "tài khoản" — pooled theo contract, không double-entry cổ điển.** Ledger KHÔNG có cặp `fromAccount/toAccount` per row; nó là sổ append-only trong đó mỗi entry mang `entryType` (chiều: LOCK\_\* nạp vào pool giữ hộ; RELEASE/REFUND/FORFEITURE/PENALTY/DAMAGES rút khỏi pool) + `fundType` + `contractId`/`milestoneId` (scope). "Tài khoản" chính là **pool tiền phong toả theo `contractId`**; escrow-service (không phải bank) là nơi validate **conservation** cho từng leg trước khi phát command (§3, §5).

4. **Số dư = SUM có dấu, không lưu balance rời.** Balance của 1 contract = `SUM(amount × sign(entryType))` trên các entry của `contractId` đó (LOCK dấu +, RELEASE/REFUND/FORFEITURE/… dấu −). **Không** persist cột balance cạnh ledger (đã nêu §5 "tránh dual-write"). Với quy mô đồ án (vài nghìn entry) `SUM` + 2 index chạy dưới 50ms (§Database) — không cần snapshot.

5. **Không âm, không zero.** Mọi bank command `amount` **strictly positive** (§3); command zero bị omit; reversal biểu diễn bằng entry `entryType` ngược dấu với amount dương, **không** dùng amount âm. Pool 1 contract không bao giờ rút quá phần đã lock (RELEASE/REFUND/FORFEITURE tổng ≤ tổng LOCK) — đây chính là conservation escrow enforce trước khi phát leg; bank là "dumb writer" tin số đã validate.

6. **Isolation — bằng append-only + unique key, không cần row-lock.** Vì ledger chỉ **INSERT** (không UPDATE in-place), không có lost-update giữa 2 writer. Chống ghi trùng bằng `UNIQUE(source_event_id)` cho command replay và `UNIQUE(remedy_leg_id)` cho từng money-leg (§4 Idempotency) — 2 request đồng thời cùng key → 1 thắng, 1 bị DB từ chối, không cần `SELECT FOR UPDATE`. Balance đọc bằng `SUM` tại query-time nên luôn phản ánh tập entry đã commit.

7. **Terminal ⇒ remaining lock = 0.** Bất biến "contract terminal ⇒ tổng lock = 0" (verification matrix #8) là điều kiện đóng: `SUM(LOCK) − SUM(RELEASE+REFUND+FORFEITURE+PENALTY+DAMAGES) = 0.00` cho `contractId` trước khi contract-service commit terminal + `LedgerAuditReconciliationJob` (§5b.1) là lưới bắt lệch.

## 3. Interaction với escrow-service — Event Flow

**Chốt (03/07/2026):** escrow-service là **actor duy nhất** gọi bank-service — contract-service không bao giờ nói chuyện trực tiếp với bank-service, giữ nguyên ranh giới đã có ("contract-service quản lý delivery state, escrow-service quản lý tiền", `milestone-escrow-phase2-design.md` §2.3).

**Không fire-and-forget — đợi confirmation, cùng pattern `EscrowEventConsumer` Phase 1 đã dùng** (contract-service đợi `escrow.buyer_locked` mới `activate()`, không tự set trước):

```
escrow-service → bank-service:  bank.lock_requested        (contractId, milestoneId?, userId, amount, sourceEventId)
bank-service   → escrow-service: bank.lock_completed        (thành công → escrow-service set state LOCKED)
                                  bank.lock_failed           (thất bại → escrow-service giữ nguyên state, xử lý theo nhánh fail)
```

Cùng pattern cho `release`, `seize`, `refund` — 4 loại request/confirmation, không cặp nào set state trước khi có confirmation.

Canonical event names for all four pairs are frozen here:

| Request | Completed | Failed |
|---|---|---|
| `bank.lock_requested` | `bank.lock_completed` | `bank.lock_failed` |
| `bank.release_requested` | `bank.release_completed` | `bank.release_failed` |
| `bank.seize_requested` | `bank.seize_completed` | `bank.seize_failed` |
| `bank.refund_requested` | `bank.refund_completed` | `bank.refund_failed` |

**Tại sao không được set trước:** nếu escrow-service publish `bank.lock_requested` rồi tự set `LOCKED` ngay, trong khi bank-service (mock) fail vì lý do gì đó — 2 bên lệch state, không ai biết cho tới khi có người kiểm tra thủ công. Đúng dạng dual-write problem đã học ở Phase 1 (`ApplicationEvent` non-durable), chỉ khác hướng: lần trước là sync-call-fail-without-rollback, lần này là async-fire-and-forget-không-đợi-confirm.

### 3.1 Ledger entries từ clean-path Delta 1/2 pro-rata — `milestone.settled` (mới, 04/07/2026)

**Bối cảnh:** `batchAmount` khoá full theo `committedQuantity × effectiveUnitPrice` tại funding request, trong đó effective price là accepted adjustment hoặc fallback `agreedPrice` (`milestone-escrow-phase2-design.md` §6.2/§6c). Nhưng Delta 1/Delta 2 pro-rata (§4 cùng file) có thể khiến số tiền thật seller đáng nhận **thấp hơn** `batchAmount` đã khoá — phần chênh lệch phải trả lại buyer, không được im lặng giữ trong pooled account.

**Chốt (04/07/2026):** payload `milestone.settled` mang `lockedAmount` (= `batchAmount` gốc) và `actualAmount` (= số tiền thật sau Delta 1/2). escrow-service nhận event, tự tính `diff = lockedAmount - actualAmount`:

```
Nếu diff > 0:
    bank.release_requested   (contractId, milestoneId, userId=sellerId, amount=actualAmount, entryType=RELEASE_TO_SELLER, sourceEventId) nếu actualAmount > 0
    bank.refund_requested    (contractId, milestoneId, userId=buyerId,  amount=diff,          entryType=REFUND_TO_BUYER,  sourceEventId khác) vì diff > 0
Nếu diff == 0 (giao đủ, không shortfall):
    bank.release_requested   (contractId, milestoneId, userId=sellerId, amount=actualAmount, entryType=RELEASE_TO_SELLER, sourceEventId) nếu actualAmount > 0
```

Mỗi request có `sourceEventId` riêng (idempotency key, §4) dù cùng phát sinh từ 1 `milestone.settled` — 2 `LedgerEntry` là 2 hành động tiền độc lập, không phải 1 hành động ghi 2 dòng.

Quality dispute không dùng nhánh này. Final quality resolution chỉ đến qua `remedy.finalized`; escrow-service reject/dedup mọi trường hợp cùng resolution còn phát `milestone.settled`. Với quality remedy, conservation kiểm riêng theo `fundType`: tổng legs `MILESTONE_PAYMENT` đúng `batchAmount`; `CONTRACTUAL_PENALTY` và `SELLER_DEPOSIT` forfeiture đối soát nguồn riêng, không cộng vào batch. Bank không thêm enum quality-specific và không tự tính penalty base; contract-service cung cấp số dựa trên `effectiveUnitPrice × committedQuantity` của milestone reject.

### 3.2 Ledger entries cho `buyerDepositRate`/`sellerDepositRate` — termination outcome biểu diễn trong `remedy.finalized` (mới 04/07/2026; sửa 19/07 — trigger theo `finalBreachingRole`; **đổi tên 19/07 lần 4:** tiêu đề cũ "Event nhận `contract.terminated`" dễ khiến người code implement consumer sai — bank KHÔNG consume `contract.terminated`, bảng dưới mô tả *outcome* theo nhánh, đường kích duy nhất là `remedy.finalized`/`remedyLegs`)

**Bối cảnh:** `buyerDepositRate` là khoá cấp Contract, không gắn milestone nào — money consequence đi qua `remedy.finalized` cấp Contract (`milestone-escrow-phase2-design.md` §6.7, §7.2). **Nguyên tắc mới (19/07):** người bấm nút chấm dứt ≠ người vi phạm; ledger seize theo **`finalBreachingRole`** đã attribution (`BreachCase` §6.4 bên milestone-escrow), không suy từ ai khởi xướng:

| Nhánh termination (outcome — kích qua `remedy.finalized.remedyLegs`) | `entryType` cho `buyerDepositRate` | `entryType` cho `sellerDepositRate` (nếu > 0) | `milestoneId` |
|---|---|---|---|
| Normal completion outcome | `REFUND_TO_BUYER` | `RELEASE_TO_SELLER` | `NULL` |
| No-fault termination outcome (`finalBreachingRole=NULL` — mutual/FM/replacement/technical) | `REFUND_TO_BUYER` | `RELEASE_TO_SELLER` (về chủ, không seize) | `NULL` |
| Seller-attributed termination outcome (`finalBreachingRole=SELLER`) | `REFUND_TO_BUYER` | `DEPOSIT_FORFEITURE` (offset vào penalty debt) | `NULL` |
| Buyer-attributed termination outcome (`finalBreachingRole=BUYER`) | `DEPOSIT_FORFEITURE` (chuyển seller) | `RELEASE_TO_SELLER` | `NULL` |

**Phân vai event (sửa 19/07 lần 2 — chặn double-consume):** bảng trên mô tả *kết quả ledger* theo nhánh; nhưng **đường kích duy nhất** cho mọi lệnh tiền termination là `remedy.finalized` (escrow đọc `remedyLegs` — mỗi leg mang `{remedyLegId, remedyType, fundType, amount, role}` (khớp schema milestone-escrow §7.2) — rồi phát `bank.*_requested` kèm `remedyDecisionId` + `remedyLegId` từng leg (dedup ở `remedy_leg_id UNIQUE`, §6 DDL)). `contract.terminated` KHÔNG kích lệnh tiền nào — nếu cả 2 event cùng kích, `sourceEventId` khác nhau làm idempotency không chặn được seize/refund trùng. `breach.reported` không có consumer nào ở tầng tiền (allegation chưa attribution). Vòng đời `buyerDepositRate`: `LOCK_BUYER_DEPOSIT` lúc `SIGNED` → một trong các entry trên. `sellerDepositRate` tương tự với `LOCK_SELLER_DEPOSIT`.

### 3.3 Ledger entries từ Provisional Settlement Level 2 — 3 event mới (08/07/2026)

**Bối cảnh:** `milestone-escrow-phase2-design.md` §3.2 định nghĩa 3 event provisional (`milestone.level2_provisional_settled` / `..._buffer_reconciled` / `..._terminal_settled`) và mechanics tiền đầy đủ 3 bước — nhưng bank-service trước bản này hoàn toàn chưa map event nào của luồng này sang `LedgerEntry`. Không cần `entryType` mới — vẫn `RELEASE_TO_SELLER`/`REFUND_TO_BUYER`, mỗi động tác 1 `sourceEventId` riêng (đúng pattern Delta 1/2 ở §3.1).

| Event nhận | Ký hiệu (xem `milestone-escrow-phase2-design.md` §3.2) | `LedgerEntry` bắn ra |
|---|---|---|
| `milestone.level2_provisional_settled` | Payload explicit `sellerReleaseAmount`, `remainingLockedAmount`; no buyer refund | Emit one positive `RELEASE_TO_SELLER(sellerReleaseAmount)` command; omit if zero |
| `milestone.level2_buffer_reconciled` | Payload explicit `sellerAdditionalReleaseAmount`, `buyerRefundAmount`, `overReleaseAmount` | Emit positive release/refund commands only; never turn `overReleaseAmount` into a negative command |
| `milestone.level2_terminal_settled` | Payload explicit terminal seller/refund legs | Emit positive release/refund commands only |

Payload mỗi event mang sẵn số tiền đã tính; contract-service tính money legs, escrow-service validates conservation and emits commands, bank-service chỉ ghi ledger theo amount nhận được, không tự tính lại `X15`/`X2`/`rate`. Mọi bank command amount phải strictly positive; zero command bị omit và reversal không dùng negative amount.

### 3.4 `bank.large_transaction_flagged` — báo cáo giao dịch giá trị lớn, không hold (mới, 08/07/2026)

**Bối cảnh:** `reputation-service-phase2-design.md` §8 (bản trước) đặt hold cứng `CONFIRM_CLEAN` cho mọi giao dịch vượt ngưỡng tuyệt đối, không phân biệt hành vi — giết happy path (đa số hợp đồng nông sản thật vượt xa ngưỡng chỉ vì khối lượng lớn) và sai chủ thể pháp lý (nghĩa vụ báo cáo giao dịch giá trị lớn thuộc **tổ chức tài chính giữ tiền**, không phải platform số hoá hợp đồng — Luật PCRT 2022 Điều 4, Thông tư 27/2025/TT-NHNN). Đã tách lại đúng vai trò ở `reputation-service-phase2-design.md` §8 — bank-service chỉ **ghi nhận + audit trail cho nghĩa vụ báo cáo**, không hold giao dịch.

**Ngưỡng — [VERIFIED ✓, 08/07/2026]; điểm phát sửa 19/07 lần 3:** signal phát tại **bank-adapter boundary khi mock/real rail thực sự thực hiện transfer** ≥ **500.000.000 VNĐ (giao dịch chuyển tiền điện tử trong nước)** → publish `bank.large_transaction_flagged` — KHÔNG phát per-`LedgerEntry` như bản cũ: một giá trị kinh tế sinh nhiều entry qua lifecycle (`LOCK_MILESTONE` → `RELEASE_TO_SELLER`/`REFUND_TO_BUYER`/`DEPOSIT_FORFEITURE`) → cùng một dòng tiền bị flag lặp nhiều lần; nghĩa vụ báo cáo pháp lý gắn với **giao dịch chuyển tiền thực**, không với bút toán nội bộ của ledger. Đây **không phải** ngưỡng "giao dịch có giá trị lớn phải báo cáo" chung (400 triệu, Điều 6 TT27/2025/TT-NHNN, kế thừa QĐ 11/2023/QĐ-TTg — áp dụng chủ yếu ngữ cảnh nộp/rút tiền mặt). Các operation của `ledger_entry` (lock/release/refund) là **chuyển khoản giữa các tài khoản ngân hàng** — đúng định nghĩa "giao dịch chuyển tiền điện tử" ở **Điều 9 Thông tư 27/2025/TT-NHNN**, ngưỡng 500 triệu (giữ nguyên từ 2007, TT27 chỉ làm rõ thêm trách nhiệm kỹ thuật, không đổi số) — 1.000 USD nếu có bên quốc tế tham gia (không áp dụng ở scope hiện tại, mock 1 pooled account nội địa). **Không dùng 400 triệu** — đó là ngưỡng cho loại giao dịch khác (tiền mặt), không phải loại giao dịch của bank-service.

**Cơ chế:** tại bank-adapter boundary, khi mock/real rail ghi nhận một **giao dịch chuyển tiền thực** đã được thực hiện, adapter đánh giá ngưỡng và publish `bank.large_transaction_flagged` nếu đủ điều kiện; không hold, không chờ Admin và không phát theo từng bút toán nội bộ `LedgerEntry`. Payload: `{transferId, relatedEntryId?, contractId, userId, amount, transferType, occurredAt}`. Consumer: reputation-service (composite fraud score, không phải trigger hold độc lập — xem `reputation-service-phase2-design.md` §8) và audit-service (bằng chứng cho nghĩa vụ báo cáo nếu sau này tích hợp ngân hàng thật). Thực tế ngân hàng thật vẫn cho giao dịch chạy rồi báo cáo Cục Phòng, chống rửa tiền trong 1 ngày làm việc (dữ liệu điện tử) — không đóng băng giao dịch chỉ vì vượt ngưỡng.

### 3.4b Consume `analytics.structuring_pattern_detected` — báo cáo giao dịch **khả nghi** (structuring), khác §3.4 (mới, 10/07/2026)

**Phân biệt với §3.4 — 2 nghĩa vụ báo cáo khác nhau, đừng gộp:** §3.4 là báo cáo **giao dịch giá trị lớn** (ngưỡng đơn ≥500 triệu, bank-service phát hiện tại bank-adapter boundary của giao dịch chuyển tiền thực). Mục này là báo cáo **giao dịch khả nghi** (structuring — hành vi rải mỏng nhiều giao dịch/hợp đồng dưới ngưỡng để né §3.4). Structuring không thể phát hiện từ một transfer đơn lẻ — chỉ thấy khi nhìn cộng dồn qua thời gian trên data warehouse. `analytics-service.AmlPatternScanJob` (batch, `analytics-service-phase2-design.md` §3.5) làm việc đó và publish `analytics.structuring_pattern_detected`.

**Vì sao bank-service là consumer, không phải reputation-service:** phát hiện structuring **mà không báo cáo cơ quan** tự nó là lỗi tuân thủ trong khung AML. Nghĩa vụ báo cáo giao dịch khả nghi (STR) thuộc **tổ chức tài chính giữ tiền** (Luật PCRT 2022 Điều 4, Điều 26 — báo cáo giao dịch đáng ngờ), cùng chủ thể đã lo báo cáo giá trị lớn ở §3.4. `reputation-service` chỉ xử lý *nội bộ* (set cặp `ELEVATED_RISK`, chặn giao dịch tương lai — `reputation-service-phase2-design.md` §8); bank-service lo nghĩa vụ *ra ngoài*. Cùng 1 event, 2 consumer, 2 vai độc lập — không phụ thuộc nhau.

**Cơ chế:** consume `analytics.structuring_pattern_detected` (payload `{buyerId, sellerId, contractIds[], nearThresholdCount, windowStart, windowEnd, detectedAt}`) → tạo `SuspiciousTransactionReport` (bản ghi nội bộ, append-only, cùng tinh thần `ledger_entry`) + publish `bank.suspicious_report_created {eventId, buyerId, sellerId, windowEnd, reportHash, occurredAt}` cho audit-service nối chain (`source_type: STRUCTURING_REPORT`; transport chốt 17/07/2026 — hash-chain §2.4, bank không INSERT thẳng `audit_record`) làm bằng chứng due diligence. **Không hold** gì ở đây (batch chạy hồi cứu, các giao dịch trong `contractIds[]` đã settle — không có gì để hold; việc chặn giao dịch *tương lai* của cặp là của `ELEVATED_RISK` bên reputation). Idempotent theo `(buyerId, sellerId, windowEnd)` — batch chạy lại cùng cửa sổ không đẻ báo cáo trùng.

**Scope đồ án (honest):** platform mock 1 pooled account nội địa, chưa tích hợp cổng báo cáo thật của Cục PCRT — `SuspiciousTransactionReport` là bản ghi sẵn sàng export (đúng field STR cần), nếu sau này tích hợp ngân hàng/cơ quan thật chỉ cần thêm adapter, không đổi business logic. Cùng tinh thần "mock legal custody" đã dùng cho toàn bộ bank-service.

### 3.5 Emergency Lock — Zero-Trust Kill Switch cho External Verifier (mới, 08/07/2026, đã review + đóng 13/07/2026)

**Bối cảnh — lỗ hổng đã ghi nhận ở `hash-chain-phase2-design.md` §6:** toàn bộ 3 lớp bảo vệ hash chain đứng trên giả định trusted-operator, và cơ chế phát hiện tampering (`VerifyChainJob`) chạy **bên trong** platform — nếu chính Admin sửa data DB rồi vô hiệu hoá/lờ job đó đi, không có gì chặn được. Kill switch này thu hẹp đúng lỗ hổng đó: cho **bên xác minh ngoài** (External Verifier) một đường tự query hash để đối soát độc lập, và một đường tự đóng băng toàn hệ thống khi phát hiện lệch — không phụ thuộc bất kỳ job nào chạy trong platform.

**Ai là External Verifier — KHÔNG cột cứng vào VICOFA:** đây là **tổ chức mua & vận hành platform** (Software Buyer — dùng đúng thuật ngữ đã có ở `hash-chain-phase2-design.md` §5.2), có thể là VICOFA, VRA, VINACAS, hoặc doanh nghiệp thu mua uy tín bất kỳ tuỳ deployment. Cơ chế chạy y hệt bất kể ai đóng vai — VICOFA chỉ là ví dụ minh hoạ thực tế nhất (đang có liên kết ngành), **không phải điều kiện bắt buộc** để cơ chế hoạt động. Mọi field/event/config dưới đây đặt tên generic (`verifierOrgId`, `EXTERNAL_VERIFIER_*`), không hardcode tên riêng tổ chức nào.

**Vì sao không dùng API key/JWT thường bảo vệ 2 endpoint này:** Admin có quyền chui DB hoặc đọc environment variable → lấy được mọi secret đối xứng (API key, JWT signing secret) lưu trong tầm với runtime. Vũ khí duy nhất trị được Admin nội bộ ở case này là **mật mã bất đối xứng** — External Verifier giữ private key trong hạ tầng của họ (platform không bao giờ biết), platform chỉ giữ **public key** để verify chữ ký. Admin xem được public key cũng vô dụng: public key chỉ kiểm tra được chữ ký, không tạo ra chữ ký.

#### 3.5.1 Ba đường, phân biệt rõ đọc vs thay-đổi-trạng-thái

| Đường | Method | Auth | Bản chất |
|---|---|---|---|
| Query hash đối soát | `GET /api/v1/security/audit-hash?contractId=...` | Nhẹ (`X-Api-Key` + rate limit) | **Chỉ đọc** — hash không phải bí mật, không cần chữ ký. **Sửa 17/07/2026: đường này do audit-service serve** (chủ data `audit_record`, hash-chain §4.4); liệt kê ở đây để giữ bức tranh "3 đường của External Verifier", bank-service chỉ implement 2 đường lock/unlock |
| Emergency lock | `POST /api/v1/security/emergency-lock` | **Chữ ký bất đối xứng** External Verifier | **Đổi trạng thái** (đóng băng tiền) — bắt buộc asymmetric |
| Emergency unlock | `POST /api/v1/security/emergency-unlock` | **Chữ ký bất đối xứng** External Verifier | **Đổi trạng thái** (mở băng) — mirror với lock, không có đường tắt cho Admin |

Query endpoint chỉ cần auth nhẹ vì đọc hash không thay đổi gì; 2 endpoint lock/unlock đổi trạng thái tiền nên bắt buộc asymmetric. **Không** gộp chung cơ chế cho cả 3 — đọc mà bắt asymmetric là thừa, đổi-trạng-thái mà chỉ API key là hở đúng lỗ Admin.

#### 3.5.2 Chống replay attack (lock & unlock)

Payload bắt buộc mang `timestamp` + `nonce`, và **cả hai nằm trong chuỗi được ký**, không để rời ngoài header:

```
signedPayload = { action: "LOCK" | "UNLOCK", reason, timestamp, nonce }
signature     = ES256(RFC8785_canonical_json(signedPayload), verifierPrivateKey)
```

HTTP body:

```json
{
  "keyId": "public-key-sha256-fingerprint",
  "signedPayload": {
    "action": "LOCK | UNLOCK",
    "reason": "string",
    "timestamp": "ISO-8601",
    "nonce": "UUID"
  },
  "signature": "base64url"
}
```

Use ES256 (ECDSA P-256 with SHA-256) over RFC 8785 canonical JSON of `signedPayload`. The action must match the endpoint; mismatch is `EXTERNAL_SIGNATURE_INVALID`. Platform verify: (1) `keyId` resolves to the registered public key; (2) signature verifies; (3) `timestamp` is within ±300 seconds; (4) `nonce` is persisted and unique. Rejection codes are fixed: `EXTERNAL_SIGNATURE_INVALID`/`EXTERNAL_KEY_UNKNOWN` -> 401; `SIGNATURE_TIMESTAMP_OUT_OF_WINDOW`/`NONCE_REPLAYED` -> 401/409 respectively; `SYSTEM_ALREADY_LOCKED`/`SYSTEM_NOT_LOCKED` -> 409.

#### 3.5.3 Gate — chốt chặn duy nhất, tận dụng "escrow-service là actor duy nhất"

Vì escrow-service là **actor duy nhất** gọi bank-service (§3), không cần sửa contract-service/escrow-service để "đóng băng toàn hệ thống" — chỉ cần **1 chốt chặn ngay đầu bank-service**: trước khi xử lý bất kỳ `bank.lock_requested`/`release_requested`/`seize_requested`/`refund_requested` nào, check `SELECT 1 FROM system_lock WHERE status='ACTIVE'`. Có row ACTIVE → **không ghi ledger**, publish `bank.*_failed` tương ứng (đúng pattern request/confirmation §3, không cần state mới). escrow-service/contract-service không cần biết gì về freeze — chúng chỉ thấy `bank.*_failed` và tự xử theo nhánh fail sẵn có.

**Quyết định scope:** `SystemLock` là global all-or-nothing kill switch **có chủ đích**, không phải phần scoped-lock bị thiếu. Khi active, nó đóng băng toàn bộ lock/release/seize/refund vì tại thời điểm phát hiện tamper chưa có cơ sở tin cậy để khoanh vùng một bank, contract hay ledger subset.

#### 3.5.4 Tách freeze (kỹ thuật) khỏi notify (con người) — giữ nguyên tinh thần hash-chain §5.2

- **Freeze:** tự động, tức thì, toàn cục, không ai duyệt. Freeze toàn cục (không phải chỉ 1 contract) vì tamper 1 điểm trong chain nghĩa là không còn tin được record nào khác cho tới khi điều tra xong — không có cơ sở khoanh vùng lúc mới phát hiện.
- **Notify tự động:** chỉ 2 nơi — Admin (điều tra kỹ thuật) + External Verifier (xác nhận đã nhận lệnh). **KHÔNG** tự động email buyer/seller thật của từng hợp đồng — giữ đúng quyết định `hash-chain-phase2-design.md` §5.2: chỉ báo buyer/seller sau khi Admin khoanh vùng đúng `contract_id` bị ảnh hưởng, tránh hoảng loạn oan cho hàng loạt hợp đồng không liên quan.
- **Cơ chế:** sau khi lock/unlock commit, bank-service publish `notification.security_lock_changed_requested` mang Admin + External Verifier contacts, action, reason, timestamp và sourceEventId. Không gọi mail provider trực tiếp. **Bổ sung (17/07/2026):** song song, publish domain event `bank.security_lock_changed {eventId, action: LOCKED|UNLOCKED, verifierOrgId, reason, signedPayload, occurredAt}` — audit-service consume để nối chain (§3.5.7, source_type theo action; hash-chain §2.4). Notification command và domain event tách vai như mọi chỗ khác.

#### 3.5.5 Unlock — mirror lock, không ngoại lệ cho Admin

Admin **không có** API/quyền nào set `system_lock.status='RELEASED'` trực tiếp. Muốn mở băng bắt buộc có request unlock **ký bởi External Verifier** (cùng cơ chế §3.5.2). Quy trình: Admin điều tra xong → báo External Verifier (ngoài hệ thống) → họ xem xét, đồng ý thì tự ký request unlock. Platform không tự động unlock trong **bất kỳ** trường hợp nào, kể cả false-positive đã chứng minh — vẫn cần chữ ký thật. Một khi có 1 ngoại lệ cho Admin (dù lý do chính đáng), cơ chế mất hết ý nghĩa vì Admin chính là bên đang phòng.

#### 3.5.6 Public key của External Verifier — root-of-trust không nằm trong tầm Admin runtime

Đây là điểm quyết định cơ chế đứng vững hay sụp. Public key **không** được lưu chỗ Admin sửa được lúc chạy (DB config table / env var) — nếu lưu đó, Admin swap public key bằng key của chính họ → tự ký giả mạo External Verifier, hoặc âm thầm đổi key để mọi cảnh báo thật bị verify fail và bị bỏ qua. Ba lớp bảo vệ root-of-trust:

1. **Genesis key baked deploy-time:** public key ban đầu nằm trong config đi theo build artifact / secret do bên vận hành hạ tầng quản lý — **không phải** "Admin" (vai trò nghiệp vụ có quyền chui DB/env runtime). Đây là 2 vai trò khác nhau; Admin runtime không có quyền redeploy hay đổi secret hạ tầng.
2. **Mọi lần rotation là 1 event anchor vào hash chain:** đăng ký/đổi public key = `source_type = 'EXTERNAL_VERIFIER_KEY_REGISTERED'` mới trong `audit_record` (`hash-chain-phase2-design.md` §2, đang bổ sung song song), **và** gửi email fingerprint key thẳng vào hộp thư External Verifier lúc đăng ký — ngoài tầm platform y hệt email anchor lúc `sign()`. Admin lén đổi giá trị config → lệch với record đã anchor trong chain (`VerifyChainJob` bắt được) và lệch với fingerprint External Verifier tự giữ.
   Email fingerprint đi qua `notification.verifier_key_anchor_requested` do bank-service publish sau khi rotation hợp lệ được ghi nhận. Ghi chain đi qua domain event `bank.verifier_key_registered {eventId, publicKeyFingerprint, rotationSignedByOldKey?, occurredAt}` (**mới 17/07/2026** — trước đây record `EXTERNAL_VERIFIER_KEY_REGISTERED` chưa có transport; audit-service là consumer, hash-chain §2.4).
3. **Rotation hợp lệ phải ký bởi key CŨ:** muốn đổi sang public key mới, cần message ký bởi private key **đang có hiệu lực** ("tôi xác nhận đổi sang public key = XYZ"). Admin không có private key nào của External Verifier → không tạo được rotation hợp lệ, chỉ đổi được giá trị DB thô và giá trị đó sẽ lệch chain/email như lớp 2.

#### 3.5.7 Lock & unlock cũng vào hash chain

Cả 2 hành động vào `audit_record` như `source_type` mới (`SECURITY_LOCK_TRIGGERED` / `SECURITY_UNLOCK_TRIGGERED`) — đúng tiêu chí Event Catalog (`hash-chain-phase2-design.md` §2: "quyết định có thể bị tranh chấp làm bằng chứng sau này"). Kill switch tự nó cũng phải tamper-evident, không chỉ tiền mới cần.

---

## 4. Idempotency

**Vấn đề — `services.md` tự ghi đây là pain point CHÍNH của bank-service, không phải phụ:** RabbitMQ at-least-once — bank-service có thể nhận cùng 1 `bank.lock_requested` 2 lần (retry, consumer restart giữa chừng). Không check → trừ/khoá tiền 2 lần cho cùng 1 giao dịch.

**Chốt (03/07/2026, cập nhật contract freeze) — idempotency key = `sourceEventId` = request envelope `eventId`.** Escrow-service tạo đúng một outbox event cho mỗi bank command; `eventId` của `bank.*_requested` được copy nguyên vào payload `sourceEventId`. Bank-service deduplicate ledger bằng `sourceEventId`/`eventId`, không dùng compound business key. Result event có `eventId` mới, giữ nguyên `sourceEventId`, `correlationId` của workflow và `causationId = request eventId`. Replay phải giữ nguyên request `eventId` và payload; result duplicate chỉ re-publish confirmation, không insert ledger lần hai.

**Xử lý duplicate:** nhận `bank.lock_requested` với `sourceEventId` đã tồn tại trong `ledger_entry` → **không insert lại**, nhưng **vẫn re-publish confirmation** tương ứng (không silent-drop) — vì lý do consumer gửi lại có thể là do confirmation lần trước bị mất trên đường về, không chỉ vì request bị gửi lại. Silent-drop sẽ khiến escrow-service treo mãi chờ confirmation không bao giờ tới.

---

## 5. Quan hệ với `EscrowAccount`/`EscrowMilestone` (escrow-service) — tránh dual-write

**Chốt (03/07/2026):** `EscrowAccount`/`EscrowMilestone` (đã có ở `milestone-escrow-phase2-design.md` §2.3) **không tự lưu lại số tiền thật** phải đồng bộ tay với bank-service. Phân tách rõ:

- **Số tiền "đã thoả thuận"** (bao nhiêu cần khoá) — contract-level deposit được suy từ signed nominal terms; milestone `batchAmount` được cố định khi funding request chọn `effectiveUnitPrice` (`milestone-escrow-phase2-design.md` §2.1/§6c). Bank nhận số canonical đã tính, không tự recompute hay lưu một competing balance.
- **Số tiền "thật đã di chuyển"** — sự thật duy nhất nằm ở `ledger_entry` bên bank-service.
- `EscrowAccount`/`EscrowMilestone` chỉ giữ **state** (`LOCKED`/`RELEASED`/`PENALIZED`...), không giữ thêm 1 con số tiền riêng nào phải giữ đồng bộ tay với bank-service — nếu giữ, đó chính là dual-write problem, chỉ là biến thể mới của lỗi đã học.

---

## 5b. Ledger ↔ Audit Chain Reconciliation + Statement Export (mới, 18/07/2026)

### 5b.1 `LedgerAuditReconciliationJob` — đối chiếu SỐ TIỀN, lấp lớp check còn thiếu

3 lớp check hiện có không lớp nào trả lời "tiền đã đi đúng như quyết toán đã anchor chưa": bank reconciliation soát ledger nội bộ; chain verify (weekly + watchdog §3.5) chỉ chứng minh **record không bị sửa**, không chứng minh **ledger khớp record**; escrow projection luôn theo ledger. Nếu bug/tamper làm release lệch số so với `milestone.settled` đã anchor → không ai bắt được tới khi có tranh chấp.

- Job `@Scheduled` (hằng ngày, sau OTS window): với mỗi milestone `SETTLED` trong kỳ, so `sum(ledger entries RELEASE/SEIZE theo milestoneId)` vs `settledAmount`/`seizedAmount` trong `audit_record.content` (content minimal hoá vẫn giữ số liệu cần verify — governance §6, nên đủ dữ liệu để so).
- Đọc audit record qua internal API read-only mới của audit-service (hash-chain §4.5): `GET /internal/v1/audit/records?contractId&sourceType&from&to` — service-to-service secret, **không route Gateway**.
- **Mismatch → alert, KHÔNG auto-fix:** publish `notification.reconciliation_mismatch_requested` (Admin only) + metric. Đường sửa duy nhất là reversal entry có attribution (§nguyên tắc ledger) — job không có quyền ghi.
- Job fail/audit-service unavailable → alert vận hành, không block dòng tiền (đây là lớp phát hiện, không phải gate).

### 5b.2 Statement export cho Buyer/Seller — bank vẫn không lộ ra ngoài

Buyer/Seller tải bảng kê bút toán liên quan tới mình (cọc khoá, release/seize từng milestone, hoàn cọc) dạng CSV/PDF làm chứng từ cho kế toán của họ — platform **không** làm kế toán hộ, **không** xuất hoá đơn (Seller tự xuất theo NĐ123).

- Mặt tiền là **escrow-service**: `GET /api/v1/escrows/statements?from&to` (nằm dưới route `/api/v1/escrows/**` sẵn có, ownership check theo participant) → Feign nội bộ `GET /internal/v1/bank/ledger?participantId&from&to` (read-only, service secret, không route Gateway — bổ sung vào nhóm internal APIs sẵn có) → render file. Bank-service giữ nguyên không có external route (gateway §3.5).
- Read-only, số liệu luôn theo ledger → không dual-write, không state/event mới.

## 6. Database

```sql
CREATE TABLE ledger_entry (
    entry_id          CHAR(36) PRIMARY KEY,
    source_event_id    CHAR(36) NOT NULL UNIQUE,   -- idempotency key, xem §4
    contract_id        CHAR(36) NOT NULL,
    milestone_id       CHAR(36) NULL,               -- NULL = cọc cấp Contract (buyer hoặc seller, phân biệt qua entry_type — sửa 08/07/2026, xem §2), có giá trị = batchAmount của milestone đó
    user_id            CHAR(36) NOT NULL,
    entry_type         VARCHAR(30) NOT NULL,    -- LOCK_BUYER_DEPOSIT | LOCK_SELLER_DEPOSIT | LOCK_MILESTONE | RELEASE_TO_SELLER | REFUND_TO_BUYER | DEPOSIT_FORFEITURE | CONTRACTUAL_PENALTY | DAMAGES_COMPENSATION (19/07/2026 — tách SEIZE_PENALTY, §2; VARCHAR nới 30 cho DAMAGES_COMPENSATION)
    fund_type          VARCHAR(30) NOT NULL,    -- 19/07 lần 4: BUYER_DEPOSIT | SELLER_DEPOSIT | MILESTONE_PAYMENT (§2 — DDL bị bỏ quên khi thêm field domain)
    remedy_decision_id CHAR(36) NULL,           -- 19/07 lần 4: group + reconciliation theo quyết định; NULL cho lock/release thường
    remedy_leg_id      CHAR(36) NULL UNIQUE,    -- 19/07 lần 4: ĐƠN VỊ DEDUP đúng — một decision hợp lệ sinh NHIỀU legs nên
                                                -- remedy_decision_id không thể UNIQUE trong ledger; mỗi leg của remedyLegs
                                                -- mang remedyLegId, replay leg → UNIQUE chặn. "Một decision → đúng một BỘ legs"
                                                -- enforce bằng remedy_leg_id UNIQUE + reconcile group theo remedy_decision_id
    amount             DECIMAL(15,2) NOT NULL,
    created_at         TIMESTAMP NOT NULL DEFAULT now()
);
CREATE INDEX idx_ledger_entry_contract ON ledger_entry(contract_id, milestone_id);
CREATE INDEX idx_ledger_entry_user ON ledger_entry(user_id);
-- Không có bảng "account" riêng — số dư luôn derive từ SUM(amount) lọc theo contract_id/milestone_id/user_id/entry_type.
```

**Kill switch — `system_lock` + `used_nonce` (§3.5):**

```sql
CREATE TABLE system_lock (
    lock_id         CHAR(36) PRIMARY KEY,
    status          VARCHAR(20) NOT NULL,    -- 'ACTIVE' | 'RELEASED'
    verifier_org_id CHAR(36) NOT NULL,           -- External Verifier (Software Buyer) đã trigger — generic, không hardcode tên tổ chức
    reason          TEXT,
    triggered_at    TIMESTAMP NOT NULL,
    released_at     TIMESTAMP NULL
);
-- Gate check §3.5.3: SELECT 1 FROM system_lock WHERE status='ACTIVE' trước mọi bank.*_requested.

CREATE TABLE used_nonce (
    nonce       VARCHAR(64) PRIMARY KEY,      -- chống replay §3.5.2
    seen_at     TIMESTAMP NOT NULL DEFAULT now()
);
-- Dọn định kỳ nonce quá cửa sổ timestamp cho phép (±300s) — không cần giữ mãi.
```

**`wallet_snapshot` — known scaling path, KHÔNG build trong Phase 2 (ghi nhận có chủ đích):**

Ở quy mô đồ án (vài trăm hợp đồng × vài milestone → vài nghìn `ledger_entry` là max thực tế), `SUM(amount)` với 2 index sẵn có chạy dưới 50ms thoải mái — không cần snapshot. Đây là scaling path đã nghĩ tới, ghi lại để defend "đã tính tới scale" khi hội đồng hỏi, cùng cách `hash-chain-phase2-design.md` §5.1 xử lý chi phí O(n) của `VerifyChainJob`:

- **Vấn đề nếu chain phình:** derive số dư qua `SUM()` là O(n) theo số entry của contract/user — với hàng triệu giao dịch (kịch bản productize dài hạn, không phải scope hiện tại) sẽ chậm dần.
- **Hướng fix — Snapshotting:** chốt sổ số dư định kỳ vào `wallet_snapshot(scope_key, total, cutoff_entry_id, snapshotted_at)`. Balance query = `snapshot.total + SUM(amount WHERE entry_id > snapshot.cutoff_entry_id)` — chỉ cộng phần mới sau snapshot.
- **Ràng buộc để không thành dual-write (§5):** snapshot phải là **derived, single-writer, idempotent** — đúng 1 job tự tính lại từ `ledger_entry` (không service nào khác ghi tay vào), cutoff dùng `cutoff_entry_id` (không dùng timestamp — timestamp có race ở biên). Snapshot chỉ là bản tính sẵn tự vá lại được từ `ledger_entry` bất cứ lúc nào, không phải nguồn số dư thứ hai phải đồng bộ tay.
- **Không code trong Phase 2** — nêu hướng + ràng buộc là đủ; build 1 job không ai stress-test nổi ở quy mô triệu-dòng chỉ tạo rủi ro "sao biết cần" mà không chứng minh được.

---

## 7. Known Limitations / Out of Scope (có chủ đích)

- **Scoped emergency lock:** freeze theo một bank/contract/milestone không có trong Phase 2; chỉ global `SystemLock` all-or-nothing. Muốn scoped freeze cần một design riêng về trust boundary, selector được ký và hành vi phần tiền không bị scope.
- **Không tích hợp API ngân hàng thật** — không ngân hàng nào ký hợp đồng API cho 1 đồ án tốt nghiệp. Mock xuyên suốt Phase 2, interface (event contract §3) thiết kế sạch để nếu sau này có ai tích hợp thật, chỉ cần thay implementation bên trong bank-service, escrow-service không đổi 1 dòng.
- **Vai trò arbitrator (docx §3.3) bị superseded** — ghi vào `decisions.md` `[2026-07-03]`, không xoá docx gốc: mock bank không đủ điều kiện độc lập/trách nhiệm pháp lý cần có cho vai arbitrator, INSPECTOR licensed org thoả điều kiện đó trong giới hạn Phase 2.
- **Roadmap docx §4.2 "Bank Integration — tích hợp escrow thật"** — định vị lại trong `decisions.md` cùng entry `[2026-07-03]`, không xoá: mục tiêu Phase 2 là thiết kế sẵn sàng tích hợp, không phải tích hợp thật.
- **Multi-bank (Agribank vs BIDV)** — không cần model, mock giả định 1 pooled account duy nhất.
- **Accounting đầy đủ / hoá đơn điện tử (18/07/2026)** — ngoài scope có chủ đích: giao dịch mua bán là giữa Buyer–Seller, hoá đơn do Seller xuất theo NĐ123; platform chỉ cung cấp chứng từ hỗ trợ (statement export §5b.2) + ledger 10 năm. Kế toán của chính platform chưa có gì để hạch toán vì chưa có fee model.
- **Kill switch phụ thuộc External Verifier tồn tại & giữ private key an toàn (§3.5)** — cơ chế chỉ chạy khi deployment có 1 tổ chức vận hành (Software Buyer) đóng vai verifier và giữ private key trong hạ tầng của họ. Không cột cứng VICOFA — bất kỳ tổ chức mua platform nào cũng đóng vai này. Nếu External Verifier để lộ private key hoặc chính họ thông đồng với Admin, cơ chế không còn tác dụng — đây là giới hạn cố hữu của mô hình trusted-operator (`hash-chain-phase2-design.md` §6), không phải lỗi thực thi. Genesis public key baked deploy-time nằm ngoài tầm Admin runtime là điều kiện tiên quyết để cơ chế đứng vững (§3.5.6).

---

## 8. Status — Bank-service Design

**Chốt (03/07/2026):** bank-service = mock legal custody duy nhất, không phải arbitrator. Mô hình FBO/Omnibus + `LedgerEntry` append-only thay cho account-per-contract — số dư luôn derive, không lưu sẵn. escrow-service là actor duy nhất gọi bank-service, đợi confirmation event mới đổi state, không fire-and-forget. Idempotency key = `sourceEventId` (Outbox message ID), không phải compound business key. `EscrowAccount`/`EscrowMilestone` không lưu số tiền riêng — tránh dual-write, số tiền thật là single source of truth ở `ledger_entry`.

**Chốt bổ sung (04/07/2026):** ledger mechanics cho 2 luồng trước đây chưa map rõ:
- **Delta 1/2 pro-rata** (§3.1) — payload `milestone.settled` mang `lockedAmount`/`actualAmount`, escrow-service tự tính diff, bắn cặp `RELEASE_TO_SELLER` + `REFUND_TO_BUYER` (chỉ khi `diff > 0`) cùng `milestoneId`.
- **Deposit cấp Contract** (§3.2) — normal settlement và mọi termination outcome đều được mô tả bằng `remedy.finalized.remedyLegs` với `milestoneId = NULL`. `contract.settled` và `contract.terminated` chỉ là event trạng thái/audit/analytics/notification, không kích ledger; remedy type hiện hành là `DEPOSIT_FORFEITURE`/`CONTRACTUAL_PENALTY`/`DAMAGES_COMPENSATION`.

**Chốt bổ sung (10/07/2026) — consume `analytics.structuring_pattern_detected`, báo cáo giao dịch khả nghi (§3.4b):** bank-service thêm 1 consumer mới cho event batch AML từ analytics-service, tạo `SuspiciousTransactionReport` (append-only) + hash audit (`source_type: STRUCTURING_REPORT`). Đây là nghĩa vụ báo cáo giao dịch **đáng ngờ** (STR, Luật PCRT 2022 Điều 4/Điều 26), tách khỏi báo cáo giá trị lớn ở §3.4 — 2 nghĩa vụ khác nhau, cùng chủ thể pháp lý giữ tiền. Không hold (batch hồi cứu, giao dịch đã settle; chặn tương lai của cặp là việc `ELEVATED_RISK` bên reputation-service). Idempotent theo `(buyerId, sellerId, windowEnd)`. Scope đồ án: bản ghi sẵn sàng export đúng field STR, chưa nối cổng Cục PCRT thật — thêm adapter sau, không đổi logic.

**Ghi nhận quyết định (đã chốt trong doc này):** arbitrator superseded + roadmap reframe — nội dung đã nằm ở phần Status; đồng bộ sang `decisions.md` là housekeeping, không block SDS.

**Chốt bổ sung (08/07/2026) — rà soát end-to-end, 3 điểm áp dụng:**
- **B6** — comment schema sai từ khi `sellerDepositRate` optional ra đời (`milestoneId=NULL` không còn duy nhất nghĩa buyer deposit); tách `entryType` thành `LOCK_BUYER_DEPOSIT`/`LOCK_SELLER_DEPOSIT` để ledger tự giải thích được, không cần tra chéo contract-service (§2, §6).
- **A3** — thêm mapping event→ledger cho Provisional Settlement Level 2 (3 event mới từ `milestone-escrow-phase2-design.md` §3.2), trước đây bank-service hoàn toàn chưa đụng luồng này (§3.3).
- **A5** — thêm `bank.large_transaction_flagged` — đúng chủ thể pháp lý (bank ghi nhận + báo cáo, không hold), đúng ngưỡng 500 triệu (Điều 9 TT27/2025/TT-NHNN) (§3.4). **Review lần 3 (19/07):** điểm phát chuyển sang adapter boundary khi transfer thực (không per-LedgerEntry — chặn flag lặp cùng một dòng tiền); `AmlPatternScanJob` (structuring) thêm dedup `patternKey = hash(buyerId, sellerId, sortedContractIds)` UNIQUE trên bảng report — quét lại cùng cửa sổ 90 ngày mỗi ngày chỉ tạo report MỚI khi cluster có contract mới hoặc risk revision tăng, không publish lại đúng một cluster cũ.

**Chốt bổ sung (08/07/2026, chiều) — thêm Kill Switch cho External Verifier (đã review + đóng lại 13/07/2026):**
- **§3.5 — Emergency Lock / Zero-Trust Kill Switch cho External Verifier:** thu hẹp lỗ hổng `hash-chain-phase2-design.md` §6 (phát hiện tampering phụ thuộc job chạy trong platform). External Verifier (generic — Software Buyer bất kỳ, không cột cứng VICOFA) tự query hash đối soát độc lập + tự đóng băng toàn hệ thống qua chữ ký bất đối xứng khi phát hiện lệch. Gate = 1 chốt chặn `system_lock` ở đầu bank-service (tận dụng escrow-service là actor duy nhất). Freeze tự động toàn cục, tách khỏi notify buyer/seller (giữ hash-chain §5.2). Unlock mirror lock, không ngoại lệ Admin. Root-of-trust (public key) baked deploy-time ngoài tầm Admin runtime, rotation ký bởi key cũ + anchor vào chain.
- **`wallet_snapshot`** (§6) — known scaling path, nêu hướng + ràng buộc chống dual-write, KHÔNG build Phase 2.

**Đã đóng (13/07/2026):** (1) đồng bộ với `hash-chain-phase2-design.md` — 2 `source_type` mới (`EXTERNAL_VERIFIER_KEY_REGISTERED`, `SECURITY_LOCK_TRIGGERED`/`_UNLOCK_`) đã có bên đó (§2.3); (2) review §3.5 end-to-end xong — mechanics freeze/unlock, root-of-trust deploy-time, rotation ký bởi key cũ + anchor chain đều nhất quán với hash-chain §5.2/§6. **Sẵn sàng promote lên SDS/Architecture.**

**Cập nhật (17/07/2026):** (1) đường đọc `audit-hash` chuyển về audit-service — bank giữ đúng 2 đường lock/unlock (§3.5.1); (2) đặt tên transport vào chain: `bank.security_lock_changed`, `bank.verifier_key_registered`, `bank.suspicious_report_created` — audit-service consume, bank không INSERT thẳng `audit_record` (hash-chain §2.4).

**Chốt bổ sung (19/07/2026) — remedyType theo attribution (đợt 6, từ file research ScholarFirst):**
- **Tách `SEIZE_PENALTY` → `DEPOSIT_FORFEITURE` / `CONTRACTUAL_PENALTY` / `DAMAGES_COMPENSATION`** (§2) — 3 chế tài luật VN trần khác nhau (BLDS 328 không cap / LTM 301 cap 8% phần bị vi phạm / LTM 302 chứng minh thật); ledger tự nói được mỗi khoản seize bù cho cái gì, chặn double recovery. Cap validate ở contract-service (`LegalProfile`), bank giữ vai "dumb ledger".
- **§3.2 attribution đổi từ `initiatedBy` sang `finalBreachingRole`**, nhưng hậu quả tiền termination chỉ được thực thi qua `remedy.finalized.remedyLegs`; `contract.terminated` không kích ledger. `finalBreachingRole = NULL` (mutual/FM/supersede/technical) → mọi cọc về đúng chủ, không seize.
- **Milestone funding lock (milestone-escrow §6b)** dùng nguyên pattern `bank.lock_requested`/`lock_failed` sẵn có (§3) — không cần API/entryType mới; retry/fail policy là việc của escrow-service.
- Consumer mới ở tầng tiền cho `remedy.finalized` (qua escrow) — `breach.reported` KHÔNG có consumer nào ở tầng tiền (invariant: allegation chưa final không đụng ledger). **Review lần 2 (19/07):** ledger thêm `fundType` (BUYER_DEPOSIT/SELLER_DEPOSIT/MILESTONE_PAYMENT — RELEASE_TO_SELLER hết mơ hồ tiền-hàng vs trả-cọc-seller) + `remedyDecisionId` nullable; `contract.terminated` KHÔNG kích lệnh tiền — `remedy.finalized` là đường duy nhất, remedyLegs mang fundType.

Bank-service — **ĐÓNG SESSION HOÀN TOÀN**: ledger mechanics + Kill Switch (§3.5) đều đã đóng, sẵn sàng đưa vào Architecture/SDS/TechnicalSpec chính thức.

---

*Design session: 03/07/2026 · Cập nhật: 04/07/2026 (ledger mechanics cho Delta 1/2 + buyerDepositRate) · Cập nhật: 08/07/2026 sáng (rà soát end-to-end: tách entryType 2 loại cọc — B6; mapping Provisional Settlement Level 2 — A3; thêm bank.large_transaction_flagged đúng ngưỡng/chủ thể pháp lý — A5) · Cập nhật: 08/07/2026 chiều (thêm §3.5 Emergency Lock Kill Switch cho External Verifier + system_lock/used_nonce schema + wallet_snapshot scaling note) · Cập nhật: 13/07/2026 (review §3.5 end-to-end, đồng bộ source_type với hash-chain §2.3 — đóng session hoàn toàn) · Cập nhật 17/07/2026 (audit-hash về audit-service; 3 domain event transport vào chain) · Cập nhật 19/07/2026 (đợt 6 — tách `SEIZE_PENALTY` thành 3 remedyType; termination money đi duy nhất qua `remedy.finalized.remedyLegs`; large-transfer signal phát tại bank-adapter boundary, không per-LedgerEntry) · Chưa code · **Sẵn sàng đưa vào Architecture/SDS/TechnicalSpec chính thức.***
